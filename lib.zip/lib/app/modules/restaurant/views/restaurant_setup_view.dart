import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:menu_manager/app/controllers/restaurant_controller.dart';
import 'package:menu_manager/app/modules/restaurant/views/restaurant_images_page.dart';
import 'package:menu_manager/app/modules/restaurant/views/restaurant_basic_info_page.dart';
import 'package:menu_manager/app/modules/restaurant/views/restaurant_type_page.dart';
import 'package:menu_manager/app/modules/restaurant/views/restaurant_city_page.dart';
import 'package:menu_manager/app/modules/restaurant/views/restaurant_location_page.dart';
import 'package:menu_manager/app/modules/restaurant/views/restaurant_phone_page.dart';

class RestaurantSetupView extends StatelessWidget {
  const RestaurantSetupView({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = Get.put(RestaurantController());

    return Scaffold(
      appBar: AppBar(
        title: const Text('إعداد المطعم'),
      ),
      body: Column(
        children: [
          Obx(() {
            return LinearProgressIndicator(
              value: (controller.currentPage.value + 1) /
                  controller.totalSteps.value,
              backgroundColor: Colors.grey[200],
              valueColor:
                  AlwaysStoppedAnimation<Color>(Theme.of(context).primaryColor),
            );
          }),
          Expanded(
            child: PageView(
              controller: controller.pageController,
              physics: const NeverScrollableScrollPhysics(),
              children: [
                RestaurantImagesPage(controller: controller),
                RestaurantBasicInfoPage(controller: controller),
                RestaurantTypePage(controller: controller),
                RestaurantCityPage(controller: controller),
                RestaurantLocationPage(controller: controller),
                RestaurantPhonePage(controller: controller),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Obx(() {
                  if (controller.currentPage.value == 0) {
                    return const SizedBox.shrink();
                  }
                  return ElevatedButton(
                    onPressed: controller.goToPreviousPage,
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 32, vertical: 16),
                      backgroundColor: Colors.grey[300],
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: const Text('السابق'),
                  );
                }),
                Obx(() {
                  if (controller.currentPage.value ==
                      controller.totalSteps.value - 1) {
                    return const SizedBox.shrink();
                  }
                  return ElevatedButton(
                    onPressed: () {
                      if (controller.validateCurrentPage()) {
                        controller.goToNextPage();
                      }
                    },
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 32, vertical: 16),
                      backgroundColor: Theme.of(context).primaryColor,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: const Text('التالي'),
                  );
                }),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
