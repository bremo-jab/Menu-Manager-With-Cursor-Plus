import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class PhoneVerificationWidget extends StatefulWidget {
  final TextEditingController phoneController;
  const PhoneVerificationWidget({required this.phoneController, super.key});

  @override
  State<PhoneVerificationWidget> createState() =>
      _PhoneVerificationWidgetState();
}

class _PhoneVerificationWidgetState extends State<PhoneVerificationWidget> {
  bool isVerifying = false;
  bool isVerified = false;
  String? verificationId;
  String? errorText;

  @override
  void initState() {
    super.initState();
    widget.phoneController.addListener(() {
      final text = widget.phoneController.text;
      if (text.startsWith('0')) {
        widget.phoneController.text = text.substring(1);
        widget.phoneController.selection = TextSelection.fromPosition(
          TextPosition(offset: widget.phoneController.text.length),
        );
      }
    });
  }

  bool isValidPalestinianPhoneNumber(String phone) {
    if (phone.isEmpty) return false;
    if (phone.length != 9) return false;
    if (!phone.startsWith('5')) return false;
    return true;
  }

  Future<void> _verifyPhone() async {
    setState(() => isVerifying = true);

    await FirebaseAuth.instance.verifyPhoneNumber(
      phoneNumber: '+970${widget.phoneController.text.trim()}',
      timeout: const Duration(seconds: 60),
      verificationCompleted: (PhoneAuthCredential credential) async {
        await FirebaseAuth.instance.signInWithCredential(credential);
        setState(() {
          isVerified = true;
          isVerifying = false;
        });
      },
      verificationFailed: (FirebaseAuthException e) {
        setState(() => isVerifying = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('فشل التحقق: ${e.message}')),
        );
      },
      codeSent: (String verId, int? resendToken) {
        verificationId = verId;
        setState(() => isVerifying = false);
        _showOtpDialog();
      },
      codeAutoRetrievalTimeout: (String verId) {
        verificationId = verId;
      },
    );
  }

  void _showOtpDialog() {
    final otpController = TextEditingController();
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('أدخل كود التحقق'),
        content: TextField(
          controller: otpController,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(hintText: '123456'),
        ),
        actions: [
          TextButton(
            onPressed: () async {
              final credential = PhoneAuthProvider.credential(
                verificationId: verificationId!,
                smsCode: otpController.text.trim(),
              );
              try {
                await FirebaseAuth.instance.signInWithCredential(credential);
                setState(() => isVerified = true);
                Navigator.of(context).pop();
              } catch (e) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('كود التحقق غير صحيح')),
                );
              }
            },
            child: const Text('تحقق'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'رقم الهاتف',
          style: GoogleFonts.cairo(
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: Colors.grey[200],
                borderRadius: const BorderRadius.only(
                  topRight: Radius.circular(12),
                  bottomRight: Radius.circular(12),
                ),
              ),
              child: Text(
                '+970',
                style: GoogleFonts.cairo(
                  fontSize: 16,
                  color: Colors.grey[700],
                ),
              ),
            ),
            Expanded(
              child: TextFormField(
                controller: widget.phoneController,
                keyboardType: TextInputType.phone,
                decoration: InputDecoration(
                  hintText: '5XXXXXXXX',
                  hintStyle: GoogleFonts.cairo(
                    color: Colors.grey[400],
                  ),
                  border: OutlineInputBorder(
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(12),
                      bottomLeft: Radius.circular(12),
                    ),
                    borderSide: BorderSide(color: Colors.grey[300]!),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(12),
                      bottomLeft: Radius.circular(12),
                    ),
                    borderSide: BorderSide(color: Colors.grey[300]!),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(12),
                      bottomLeft: Radius.circular(12),
                    ),
                    borderSide:
                        BorderSide(color: Theme.of(context).primaryColor),
                  ),
                  errorBorder: OutlineInputBorder(
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(12),
                      bottomLeft: Radius.circular(12),
                    ),
                    borderSide: BorderSide(color: Colors.red[300]!),
                  ),
                  focusedErrorBorder: OutlineInputBorder(
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(12),
                      bottomLeft: Radius.circular(12),
                    ),
                    borderSide: BorderSide(color: Colors.red[300]!),
                  ),
                  contentPadding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 12,
                  ),
                  errorText: errorText,
                ),
                style: GoogleFonts.cairo(fontSize: 16),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    setState(() => errorText = 'الرجاء إدخال رقم الهاتف');
                    return '';
                  }
                  if (!isValidPalestinianPhoneNumber(value)) {
                    setState(() => errorText =
                        'الرجاء إدخال رقم هاتف فلسطيني صحيح (5XXXXXXXX)');
                    return '';
                  }
                  setState(() => errorText = null);
                  return null;
                },
                onChanged: (value) {
                  if (value.isEmpty) {
                    setState(() => errorText = 'الرجاء إدخال رقم الهاتف');
                  } else if (!isValidPalestinianPhoneNumber(value)) {
                    setState(() => errorText =
                        'الرجاء إدخال رقم هاتف فلسطيني صحيح (5XXXXXXXX)');
                  } else {
                    setState(() => errorText = null);
                  }
                },
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        ElevatedButton(
          onPressed: isVerified || isVerifying ? null : _verifyPhone,
          child: isVerifying
              ? const CircularProgressIndicator()
              : const Text('تحقق'),
        ),
      ],
    );
  }
}
